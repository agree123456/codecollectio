# 'Module dir/__init__.py'
VERSION = 3.8

def print_module_info():
    print("eBEST OPEN API를 이용한 자동 트레이딩 시스템(가제) 모듈입니다.")