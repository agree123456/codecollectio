# 모듈 import
# warning
import warnings
warnings.filterwarnings("ignore")

# 접속 모듈
from ebestapi import EbestAPI

# 현물주문 Class
class StockOrder(EbestAPI):
    def __init__(self, app_key, app_secret, _order_body_params):
        super().__init__(app_key, app_secret)
        # URL 재설정
        self._path = "stock/order"
        
        # 거래코드와 바디 설정
        self.tr_cd = "CSPAT00601"
        self._order_body_params = _order_body_params
        self.body = self.make_body(self._order_body_params)
        
        # 주문결과 JSON 데이터 확인
        self._json_data = self.make_request(self._path, self.tr_cd, self.body)
        
        # 데이터프레임으로 변환
        self.outblock_list = ["OutBlock1", "OutBlock2"]
        self._data_frame = self.make_df(self._json_data, self.tr_cd, self.outblock_list)
        
        # CSV로 저장
        # self.save_csv(self._data_frame, self.tr_cd)
        
    # 바디 생성 함수
    def make_body(self, _order_body_params):
        _body = {
            "CSPAT00601InBlock1": {
                  "IsuNo" : _order_body_params['ticker'] # 종목번호(앞에 A 필수)
                , "OrdQty" : _order_body_params['ord_qty'] # 주문수량
                , "OrdPrc" : _order_body_params['ord_price'] # 주문가
                , "BnsTpCode" : _order_body_params['bnstp_code'] # 매매구분(1:매도, 2:매수)
                , "OrdprcPtnCode" : _order_body_params['ord_prc_code'] # 호가유형코드
                , "MgntrnCode" : '000' # 신용거래코드
                , 'LoanDt' : '' # 대출일 (없으면 빈칸)
                , 'OrdCndiTpCode' : '0' # 주문조건(0:없음, 1:IOC, 2:FOK)
            }
        }
        
        return _body
    
# 현물정정 주문 Class
class CorrectionOrder(EbestAPI):
    def __init__(self, app_key, app_secret, _order_body_params):
        super().__init__(app_key, app_secret)
        # URL 재설정
        self._path = "stock/order"
        
        # 거래코드와 바디 설정
        self.tr_cd = "CSPAT00701"
        self._order_body_params = _order_body_params
        self.body = self.make_body(self._order_body_params)
        
        # 주문결과 JSON 데이터 확인
        self._json_data = self.make_request(self._path, self.tr_cd, self.body)
        
        # 데이터프레임으로 변환
        self.outblock_list = ["OutBlock1", "OutBlock2"]
        self._data_frame = self.make_df(self._json_data, self.tr_cd, self.outblock_list)
        
        # CSV로 저장
        # self.save_csv(self._data_frame, self.tr_cd)
        
    # 바디 생성 함수
    def make_body(self, _order_body_params):
        _body = {
            "CSPAT00701InBlock1" : {
              "OrgOrdNo" : _order_body_params['org_ord_no']
            , "IsuNo" : _order_body_params['ticker']
            , "OrdQty" :_order_body_params['ord_qty']
            , "OrdprcPtnCode" : _order_body_params['ord_prc_code']
            , "OrdCndiTpCode" : _order_body_params['ord_cnd_tp_code']
            , "OrdPrc" : _order_body_params['ord_price']
            }
        }
        
        return _body

# 현물취소 주문 Class
class CancelOrder(EbestAPI):
    def __init__(self, app_key, app_secret, _order_body_params):
        super().__init__(app_key, app_secret)
        # URL 재설정
        self._path = "stock/order"
        
        # 거래코드와 바디 설정
        self.tr_cd = "CSPAT00801"
        self._order_body_params = _order_body_params
        self.body = self.make_body(self._order_body_params)
        
        # 주문결과 JSON 데이터 확인
        self._json_data = self.make_request(self._path, self.tr_cd, self.body)
        
        # 데이터프레임으로 변환
        self.outblock_list = ["OutBlock1", "OutBlock2"]
        self._data_frame = self.make_df(self._json_data, self.tr_cd, self.outblock_list)
        
        # CSV로 저장
        # self.save_csv(self._data_frame, self.tr_cd)
        
    # 바디 생성 함수
    def make_body(self, _order_body_params):
        _body = {
            "CSPAT00801InBlock1": {
                  "OrgOrdNo" : _order_body_params['org_ord_no']
                , "IsuNo" : _order_body_params['ticker']
                , "OrdQty" : _order_body_params['ord_qty']
            }
        }
        
        return _body
    
# 현물주문 바디 파라미터 설정
def make_order_params(ticker, ord_qty, ord_price, bnstp_code):
    '''
    # 바디에 넣어줄 파라미터 설정
    # 테스트에서는 편의상 전부 시장가로 주문하겠습니다.
    # 추후 모델이 산출한 변수들로 대입
    '''
    _order_body_params = {
        'ticker' : 'A192650' # 종목번호(앞에 A 필수)
        , 'ord_qty': 500 # 주문수량
        , 'ord_price' : 0 # 주문가
        , 'bnstp_code' : '2' # 매매구분(1:매도, 2:매수)
        , 'ord_prc_code' : '03' # 호가유형코드, 테스트에서는 시장가 대입
    }
    return _order_body_params

## 정정주문 바디 파라미터 설정
def make_correction_order_params(ticker, ord_qty, ord_price, bnstp_code):
    _order_body_params = {
        'org_ord_no' : 0 # 원주문번호
        , 'ticker' : 'A192650' # 주식 : 종목코드 or A+종목코드(모의투자는 A+종목코드)
        , 'ord_qty' : 500 # 주문수량
        , 'ord_prc_code' : '03' # 호가유형코드
        , 'ord_cnd_tp_code' : '0' # 주문조건구분 (0:없음, 1:IOC, 2:FOK)
        , 'ord_price' : 0 # 주문가
    }
    return _order_body_params


# 취소주문 바디 파라미터 설정
def make_cancel_order_params(ticker, ord_qty):
    _order_body_params = {
        'org_ord_no' : 0  # 원주문번호
        , 'ticker' : 'A005930'  # 주식 : 종목코드 or A+종목코드(모의투자는 A+종목코드)
        , 'ord_qty' : 10    # 주문량
    }
    return _order_body_params

# OPEN API 키 설정
APP_KEY = 'PSGfwLiFjkhtsSvd206vLlSS3B2KBUN8FThC'
APP_SECRET = '2j2l3tfh8ObeserXe6YGsIRtoRJFT3UE'

# 파라미터 주입
ticker = ""
ord_qty = 0
ord_price = 0
bnstp_code = ""

# 주문 실행
_order_body_params = make_order_params(ticker, ord_qty, ord_price, bnstp_code)
stock_order = StockOrder(APP_KEY, APP_SECRET, _order_body_params)

# 정정주문 실행
_correction_order_params = make_correction_order_params(ticker, ord_qty, ord_price, bnstp_code)
corr_order = CorrectionOrder(APP_KEY, APP_SECRET, _correction_order_params)

# 취소주문 실행
_cancel_order_params = make_cancel_order_params(ticker, ord_qty)
cancel_order = CancelOrder(APP_KEY, APP_SECRET, _cancel_order_params)